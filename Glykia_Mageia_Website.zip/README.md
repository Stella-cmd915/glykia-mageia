# Website Ζαχαροπλαστείου "Γλυκιά Μαγεία"

## Περιγραφή Έργου

Ολοκληρωμένο website ζαχαροπλαστείου με δυνατότητα online παραγγελιών, διαχείρισης παραγγελιών από πελάτες και admin panel για υπαλλήλους.

## Δομή Αρχείων

```
website/
├── index.html              - Αρχική σελίδα
├── order-form.html         - Φόρμα παραγγελίας custom τούρτας
├── my-orders.html          - Διαχείριση παραγγελιών πελατών
├── admin-orders.html       - Admin: Διαχείριση παραγγελιών
├── admin-products.html     - Admin: Διαχείριση προϊόντων
├── styles.css              - Custom CSS στυλ
├── generate-report.js      - Script για δημιουργία τεχνικής έκθεσης
├── Texniki_Ekthesi_Website.docx  - Τεχνική Έκθεση (Word)
└── README.md               - Αυτό το αρχείο
```

## Τεχνολογίες

- **HTML5** - Semantic elements (header, nav, section, footer)
- **CSS3** - Custom styling με animations
- **Bootstrap 5.3.2** - Responsive framework
- **Bootstrap Icons** - Εικονίδια
- **JavaScript** - Client-side λειτουργικότητα
- **FullCalendar** - Ημερολόγιο εκδηλώσεων

## Χαρακτηριστικά

### Για Πελάτες
- ✅ Περιήγηση προϊόντων
- ✅ Παραγγελία custom τούρτας με live υπολογισμό τιμής
- ✅ Προβολή παραγγελιών
- ✅ Τροποποίηση παραγγελιών
- ✅ Ακύρωση παραγγελιών
- ✅ Ημερολόγιο εκδηλώσεων και προσφορών

### Για Admin
- ✅ Dashboard με στατιστικά
- ✅ Διαχείριση παραγγελιών (CRUD)
- ✅ Διαχείριση προϊόντων (CRUD)
- ✅ Φίλτρα και αναζήτηση
- ✅ Bulk actions
- ✅ Status updates

## Εγκατάσταση & Εκτέλεση

### Άνοιγμα Website
1. Ανοίξτε το `index.html` σε browser
2. Για local testing, χρησιμοποιήστε Live Server (VS Code) ή οποιοδήποτε local web server

### Deployment
Το website είναι static και μπορεί να φιλοξενηθεί σε:
- GitHub Pages
- Netlify
- Vercel
- Οποιονδήποτε web server

Απλά ανεβάστε όλα τα αρχεία HTML/CSS στον server σας.

## Οδηγίες Χρήσης

### Πλοήγηση
1. **Αρχική Σελίδα**: Περιήγηση προϊόντων, υπηρεσιών, ημερολόγιο
2. **Παραγγελία**: Κλικ στο "Παραγγείλτε Τώρα" ή "Νέα Παραγγελία"
3. **Οι Παραγγελίες μου**: Δείτε και διαχειριστείτε τις παραγγελίες σας

### Admin Access
- Πρόσβαση μέσω του footer link "Admin" ή απευθείας στο `admin-orders.html`
- **Σημείωση**: Σε παραγωγικό περιβάλλον απαιτείται authentication

## Κάλυψη Απαιτήσεων

### Αρχική Σελίδα
- ✅ Header με HTML5 semantic element
- ✅ Footer με HTML5 semantic element
- ✅ Μενού πλοήγησης 2 επιπέδων
- ✅ Κεντρικό μήνυμα επιχείρησης
- ✅ Slideshow (Bootstrap Carousel)
- ✅ Ημερολόγιο (FullCalendar)
- ✅ Σημαντικές πληροφορίες (Υπηρεσίες, Testimonials, Newsletter)

### Διαχείριση Δεδομένων
- ✅ Φόρμες εισαγωγής (order-form.html)
- ✅ Φόρμες τροποποίησης (my-orders.html, modals)
- ✅ Φόρμες διαγραφής (my-orders.html, admin panels)
- ✅ Παραδείγματα λειτουργίας για πελάτες
- ✅ Παραδείγματα λειτουργίας για υπαλλήλους

## Responsive Design

Το website προσαρμόζεται σε:
- 📱 Mobile (< 768px)
- 📱 Tablet (768px - 992px)  
- 💻 Desktop (> 992px)

## Χρωματική Παλέτα

- **Pink Primary** (#FF69B4) - Κύρια χρώμα
- **Pink Light** (#FFB6C1) - Backgrounds
- **Cream** (#FFF8DC) - Sections
- **Gold** (#FFD700) - Accents
- **Light Pink** (#FFF0F5) - Backgrounds

## Browser Compatibility

Δοκιμασμένο σε:
- ✅ Google Chrome
- ✅ Mozilla Firefox
- ✅ Safari
- ✅ Microsoft Edge

## Μελλοντικές Επεκτάσεις

Για πλήρη production-ready εφαρμογή:
- Backend API (Node.js/PHP/Python)
- Database (MySQL/PostgreSQL/MongoDB)
- User Authentication
- Payment Gateway Integration
- Email Notifications
- Image Upload & Storage
- Real-time Order Tracking
- Analytics Dashboard

## Τεχνική Έκθεση

Δείτε το αρχείο `Texniki_Ekthesi_Website.docx` για λεπτομερή τεχνική τεκμηρίωση που περιλαμβάνει:
- Εισαγωγή και σκοπό
- Τεχνολογίες που χρησιμοποιήθηκαν
- Σχεδιαστικές αποφάσεις
- Λεπτομερή περιγραφή κάθε σελίδας
- Κάλυψη απαιτήσεων
- UX Features
- Συμπεράσματα

## Σημειώσεις

- Όλες οι λειτουργίες είναι **demo/mockup** χωρίς backend
- Τα forms δεν αποθηκεύουν πραγματικά δεδομένα
- Οι παραγγελίες είναι hardcoded για επίδειξη
- Για production χρειάζεται backend implementation

## Credits

- **Bootstrap 5**: https://getbootstrap.com
- **Bootstrap Icons**: https://icons.getbootstrap.com
- **FullCalendar**: https://fullcalendar.io

## Άδεια

Αυτό το project δημιουργήθηκε για εκπαιδευτικούς σκοπούς (Web Design I Course).

---

**Ημερομηνία Ολοκλήρωσης**: Ιανουάριος 2025  
**Μάθημα**: WDI.P1 - Σχεδιασμός Διεπαφής Website
